

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Artikel'); ?>
<?php $__env->startPush('styles'); ?>
    <style>.navbar {background-color: #fff} .nav-link {color: #777 !important} .nav-link:hover {color: #6814E1 !important}</style>
<?php $__env->stopPush(); ?>

<section class="students">
    <div class="container">
        <div class="section-header">
            <h1>Daftar Artikel</h1>
            <div class="divider"></div>
        </div>
        <div class="section-body">
            <div class="row">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="<?php echo e(Storage::url('images/articles/'.$article->thumbnail_image_name)); ?>" alt="" class="card-img-top">
                        <div class="card-body">
                            <h3 class="card-title"><a href="<?php echo e(route('article.show', ['id' => $article->id])); ?> "><?php echo e($article->title); ?></a></h3>
                            <p class="card-description"><?php echo e(substr($article->content, 0, 110)); ?>. <a href="#">Lihat selengkapnya</a></p>
                        </div>
                        <div class="card-footer">
                            <div class="card-author">
                                <i class="fas fa-user-circle"></i> <span><?php echo e($article->author->name); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="paginate float-right mt-2">
                <?php echo e($articles->links()); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Code\Laravel\kelas\resources\views/articles/index.blade.php ENDPATH**/ ?>