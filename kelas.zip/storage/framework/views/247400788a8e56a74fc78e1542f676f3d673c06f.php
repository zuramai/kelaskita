

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Siswa'); ?>
<?php $__env->startPush('styles'); ?>
    <style>.navbar {background-color: #fff} .nav-link {color: #777 !important} .nav-link:hover {color: #6814E1 !important}</style>
<?php $__env->stopPush(); ?>

<section class="student">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <img src="<?php echo e(Storage::url('images/students/'.$student->image_name)); ?>" alt="">
            </div>
            <div class="col-md-9 sm:mt-5">
                <h1 class='mb-3'><?php echo e($student->name); ?></h1>
                <p><?php echo nl2br($student->description); ?></p>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Code\Laravel\kelas\resources\views/students/detail.blade.php ENDPATH**/ ?>