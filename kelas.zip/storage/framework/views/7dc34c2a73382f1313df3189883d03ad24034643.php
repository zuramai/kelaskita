<!-- =========================================================================================
  Name: KelasKita Website
  Author: Ahmad Saugi
  Author URL: http://ahmadsaugi.com
  Repository: https://github.com/zuramai/kelaskita
  Community: Devover ID
  Community URL : http://devover.id
========================================================================================== -->
		<meta content="Admin Dashboard" name="description" />
        <meta content="Ahmad Saugi" name="author" />
        <link rel="shortcut icon" href="<?php echo e(URL::asset('assets/images/favicon.ico')); ?>">

        <?php echo $__env->yieldContent('css'); ?>

        <link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets/css/metismenu.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css"><?php /**PATH D:\Programmer\Code\Laravel\kelas\resources\views/layouts/head.blade.php ENDPATH**/ ?>