<!-- =========================================================================================
  Name: KelasKita Website
  Author: Ahmad Saugi
  Author URL: http://ahmadsaugi.com
  Repository: https://github.com/zuramai/kelaskita
  Community: Devover ID
  Community URL : http://devover.id
========================================================================================== -->



<?php $__env->startSection('content'); ?>
<?php $__env->startSection('logo', Storage::url('/images/logo/'.config('web_config')['WEB_LOGO_WHITE'])); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/front.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.css')); ?>">
<?php $__env->stopPush(); ?>
<section class="hero" style="background-image: linear-gradient(to right, rgba(74, 0, 224, .9), rgba(142, 45, 226,.9)),url(<?php echo e(Storage::url("images/front/".config('web_config')['HERO_BACKGROUND_IMAGE'])); ?>)">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="hero-text text-center">
                    <div class="text-title"><?php echo e(config('web_config')['HERO_TEXT_HEADER']); ?></div>
                    <p><?php echo e(config('web_config')['HERO_TEXT_DESCRIPTION']); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="students">
    <div class="container">
        <div class="section-header text-center">
            <h1>Daftar Siswa</h1>
            <div class="divider mx-auto"></div>
        </div>
        <div class="section-body">
            <div class="row">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-5">
                    <a href="<?php echo e(route('student.show', ['id' => $student->id])); ?>" class='card-student'>
                        <div class="card">
                            <div class="row">
                                <div class="col-4">
                                    <img src="<?php echo e(Storage::url('images/students/'.$student->image_name)); ?>" alt="<?php echo e($student->name); ?>">
                                </div>
                                <div class="col-8 py-3 px-3">
                                    <div class="student-name mb-2"><?php echo e($student->name); ?></div>
                                    <p class='student-description'><?php echo e(substr($student->description,0,125)); ?>.. <span class='text-blue'>Selengkapnya</span></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class='text-right mt-5'>
                <a href="<?php echo e(route('student.index')); ?>" >Lihat Selengkapnya <i class='mdi mdi-chevron-right'></i></a>
            </div>
        </div>
    </div>
</section>
<section class="articles">
    <div class="container">
        <div class="section-header text-center">
            <h1>Artikel</h1>
            <div class="divider mx-auto"></div>
        </div>
        <div class="section-body">
            <div class="row">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="<?php echo e(Storage::url('images/articles/'.$article->thumbnail_image_name)); ?>" alt="" class="card-img-top">
                        <div class="card-body">
                            <h3 class="card-title"><a href="<?php echo e(route('article.show', ['id' => $article->id])); ?>"><?php echo e($article->title); ?></a></h3>
                            <p class="card-description"><?php echo e(substr($article->content, 0, 110)); ?>. <a href="#">Lihat selengkapnya</a></p>
                        </div>
                        <div class="card-footer">
                            <div class="card-author">
                                <i class="fas fa-user-circle"></i> <span><?php echo e($article->author->name); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class='text-right mt-3'>
                <a href="<?php echo e(route('article.index')); ?>">Lihat Semua Artikel <i class="mdi mdi-chevron-right"></i></a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Code\Laravel\kelas\resources\views/home.blade.php ENDPATH**/ ?>