 <!-- =========================================================================================
  Name: KelasKita Website
  Author: Ahmad Saugi
  Author URL: http://ahmadsaugi.com
  Repository: https://github.com/zuramai/kelaskita
  Community: Devover ID
  Community URL : http://devover.id
========================================================================================== -->
       <!-- jQuery  -->
        <script src="<?php echo e(URL::asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/js/metisMenu.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/js/waves.min.js')); ?>"></script>

        <script src="<?php echo e(URL::asset('assets/plugins/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>

        <?php echo $__env->yieldContent('script'); ?>

        <!-- App js -->
        <script src="<?php echo e(URL::asset('assets/js/app.js')); ?>"></script>
        
        <?php echo $__env->yieldContent('script-bottom'); ?><?php /**PATH D:\Programmer\Code\Laravel\kelas\resources\views/layouts/footer-script.blade.php ENDPATH**/ ?>