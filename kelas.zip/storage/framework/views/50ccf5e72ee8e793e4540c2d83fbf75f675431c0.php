

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', $article->title); ?>
<?php $__env->startPush('styles'); ?>
    <style>.navbar {background-color: #fff} .nav-link {color: #777 !important} .nav-link:hover {color: #6814E1 !important}</style>
<?php $__env->stopPush(); ?>

<section class="article">
    <div class="container">
        <div class="card">
            <img src="<?php echo e(Storage::url('images/articles/'.$article->thumbnail_image_name)); ?>" class='card-img-top'>
            <div class="card-body pt-4">
                <div class="card-detail">
                    <span><i class="fas fa-user-circle"></i> <?php echo e($article->author->name); ?></span> <span class='ml-10'><?php echo e(Carbon\Carbon::parse($article->created_at)->format('d F Y H:i:s')); ?></span>
                </div>
                <h1 class="card-title mt-2"><?php echo e($article->title); ?></h1>
                <p><?php echo nl2br($article->content); ?></p>
            </div>
        </div>
        <div class="thumbnail">
        </div>
        
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Code\Laravel\kelas\resources\views/articles/detail.blade.php ENDPATH**/ ?>